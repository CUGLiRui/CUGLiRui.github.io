E. Taillard. "Benchmarks for basic scheduling problems", European Journal of Operational Research, Vol. 64, Issue 2, pp. 278-285, 1993.

https://github.com/tamy0612/JSPLIB

数据格式：

The first line of each instance contains the number of jobs and  the number of machines. The remaining lines contain one job each, listing the machine number and processing time for each step of the job. You may choose whether the machine indices start with 0 or 1.

**the number of steps of the job is equal to the number of machines.**