#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<sys/time.h>
#include"mpi.h"


#define averageScore  3.528350
#define userNum  943
#define itemNum  1682 
#define factorNum 5
#define learnRate 0.009
#define regularzation 0.05
#define dataNum 20000

#define ROWL 314
#define COLL 560
#define tROWL 315
#define tCOLL 562

double Average(char* fileName) {
	FILE*fi;
	double result;
	int cnt,user,item,rating;
	long temp;
	result = 0.0;
	cnt = 0;
	if ((fi = fopen(fileName, "r")) == NULL) {
		printf("can not open the file\n");
		exit(0);
	}
	while (fscanf(fi, "%d %d %d %ld", &user, &item, &rating, &temp) != EOF) {
		cnt = cnt + 1;
		result += rating;
	}
	fclose(fi);
	return result / cnt;
}

double InerProduct(double*v1, double *v2) {
	double result;
	result = 0;
	int i,len;
	len = sizeof(v1) / sizeof(double);
	for (i = 0; i < len; i++) {
		result += v1[i] * v2[i];
	}

	return result;
}

double PredictScore(double av, double bu, double bi, double *pu, double *qi) {
	double pSore = av + bu + bi + InerProduct(pu, qi);
	if (pSore < 1) {
		pSore = 1;
	}
	else if (pSore > 5) {
		pSore = 5;
	}

	return pSore;
}

double Validate(char*testDataFile, double av, double*bu, double*bi, double pu[userNum][factorNum], double qi[itemNum][factorNum]) {
	int cnt;
	double rmse,tScore,pScore;
	long temp;
	int uid, iid;
	cnt = 0;
	rmse = 0.0;
	FILE*fi;
	if ((fi = fopen(testDataFile, "r")) == NULL) {
		printf("can not open\n");
	}
	while (fscanf(fi, "%d %d %lf %ld", &uid, &iid, &tScore, &temp) != EOF) {
		cnt++;
		pScore = PredictScore(av, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
		rmse += (tScore - pScore)*(tScore - pScore);
	}
	fclose(fi);
	return sqrt(rmse / cnt);
}

void File_Spreate(char*trainDataFile) {
	int threadNum = 3;
	int row_length = userNum / threadNum;
	int col_length = itemNum / threadNum;
	int uid, iid,t_col=0,t_row=0,i,j;
	int Score;
	long time;
	
	char str[100];
	char temp[100];
	char seq[3];
	strcpy(str, "./mydata/r");
	FILE*tr,*f[9];
	//create block file,open threadNum*threadNum file ptr one time for writing rating
	seq[2] = '\0';
	for (i = 0; i < threadNum; i++) {
		seq[0] = (char)(i + 48);
		for (j = 0; j < threadNum; j++) {
			seq[1] = (char)(j + 48);
			strcpy(temp, str);
			strcat(temp, seq);
			f[i*threadNum+j] = fopen(temp, "w");
		}
	}

	tr=fopen(trainDataFile,"r");
	while (fscanf(tr, "%d %d %d %ld", &uid, &iid, &Score, &time) != EOF) {
		t_row = (uid-1) / row_length;
		t_col = (iid-1)/ col_length;
		if (t_col == 3) { t_col = 2; }
		if (t_row == 3) { t_row = 2; }
		fprintf(f[t_row*threadNum + t_col], "%d %d %d\n", uid-1, iid-1, Score);
	}


	for (i = 0; i < threadNum*threadNum; i++) {
		fclose(f[i]);
	}

	fclose(tr);
	printf("Finish File Spreate\n");
}

void SVD(char*configureFile, char*testFile,char*trainDataFile) {
	/*get the configure*/
	int cnt=0;
	int i, j, step, uid, iid, k;
	long ti;
	double rmse=0.0, tScore, pScore;
	double bi[itemNum], bu[userNum], qi[itemNum][factorNum], pu[userNum][factorNum];
	double preRmse = 1000000.0, curRmse, temp, eui;

	FILE*fii,*fi,*fo;

	//memset(bi, 0, itemNum * sizeof(double));
	//memset(bu, 0, userNum * sizeof(double));
	temp = sqrt(factorNum);
	srand((unsigned)time(NULL));
	double y;
	for (i = 0; i < itemNum; i++) {
		for (j = 0; j < factorNum; j++) {
			y = rand();
			//qi[i][j] = 0.1*(y/RAND_MAX+0.0) / temp;
			qi[i][j] = 1.0;
		}
	}

	for (i = 0; i < userNum; i++) {
		for (j = 0; j < factorNum; j++) {
			y = rand();
			//pu[i][j] = 0.1*(y/RAND_MAX + 0.0) / temp;
			pu[i][j] = 1.0;
		}
	}
	//printf("%lf %lf\n", qi[0][0], qi[0][1]);
	printf("initialization end\nstart training\n");

	/*train model*/

	if ((fo = fopen("rmse.txt", "w+")) == NULL) {
		printf("can not open\n");
	}
	i = 0;
	for (step = 0; step < 100000; step++) {
		fi = fopen(trainDataFile, "r");
		while (fscanf(fi, "%d %d %lf %ld", &uid, &iid, &tScore, &ti) != EOF) {
			i = i + 1;
			uid--;
			iid--;
			//pScore = PredictScore(averageScore, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
			pScore = PredictScore(averageScore, 0, 0, &pu[uid][0], &qi[iid][0]);
			eui = tScore - pScore;
			/*update parameters*/
			bu[uid] += learnRate*(eui - regularzation*bu[uid]);
			bi[iid] += learnRate*(eui - regularzation*bi[iid]);
			for (k = 0; k < factorNum; k++) {
				temp = pu[uid][k];
				pu[uid][k] += learnRate*(eui*qi[iid][k] - regularzation*pu[uid][k]);
				qi[iid][k] += learnRate*(eui*temp - regularzation*qi[iid][k]);
			}
		}
		fclose(fi);

		//Valilde the data
		if ((fii = fopen(testFile, "r")) == NULL) {
			printf("can not open\n");
		}
		while (fscanf(fii, "%d %d %lf %ld", &uid, &iid, &tScore, &ti) != EOF) {
			cnt++;
			uid--;
			iid--;
			//pScore = PredictScore(averageScore, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
			pScore = PredictScore(averageScore, 0, 0, &pu[uid][0], &qi[iid][0]);
			eui = tScore - pScore;
			rmse += eui*eui;
		}
		fclose(fii);
		curRmse = sqrt(rmse / cnt);

		printf("test_RMSE in step %d:%lf\n", step, curRmse);
		fprintf(fo, "%lf\n", curRmse);
		if (curRmse > preRmse||curRmse==preRmse||preRmse-curRmse<pow(10,-6)) { 
			printf("it is time to break\n");
				break; 
		}
		else { 
			preRmse = curRmse; 
		}
	}
	fclose(fo);
}
/*
int main(){
	struct timeval tv1,tv2;
	gettimeofday(&tv1,NULL);
	SVD("svd.conf","u1.test","u1.base");
	gettimeofday(&tv2,NULL);
	printf("average time:%.4fms\n",((double)(tv2.tv_sec-tv1.tv_sec)*1000+(double)(tv2.tv_usec-tv1.tv_usec)/1000));
	return 0;
}*/

int main(int argc,char *argv[]) {
	//DSGD
	int rank,numtasks,flag;
	double user_buffer_1[ROWL][factorNum],user_buffer_2[ROWL][factorNum],user_buffer_3[tROWL][factorNum];
	double item_buffer_1[COLL][factorNum],item_buffer_2[COLL][factorNum],item_buffer_3[tCOLL][factorNum];
	
	struct timeval tv1,tv2;
	gettimeofday(&tv1,NULL);
	MPI_Status status[6];
	MPI_Request request[6];

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

	flag=0; //use to tag which round is now

	int uid,iid,Score,k,i,t_u,t_i;
	double eui,pScore,preRmse= 1000000.0,curRmse,rmse1,rmse2,rmse3;
	//intitialize userbuffer itembuffer
	for(i=0;i<ROWL;i++){
		for(k=0;k<factorNum;k++){
			user_buffer_1[i][k]=1.0;
			user_buffer_2[i][k]=1.0;
		}
	}
	for(i=0;i<tROWL;i++){
		for(k=0;k<factorNum;k++){
			user_buffer_3[i][k]=1.0;
		}
	}

	for(i=0;i<COLL;i++){
		for(k=0;k<factorNum;k++){
			item_buffer_1[i][k]=1.0;
			item_buffer_2[i][k]=1.0;
		}
	}
	for(i=0;i<tCOLL;i++){
		for(k=0;k<factorNum;k++){
			item_buffer_3[i][k]=1.0;
		}
	}
	FILE *fo;
	fo=fopen("prmse.txt","w+");
while(1){

	if(rank==0){
		FILE*f1;
		if(flag==0){f1=fopen("./mydata/r00","r");}
		if(flag==1){f1=fopen("./mydata/r01","r");}
		if(flag==2){f1=fopen("./mydata/r02","r");}
		//training
		while(fscanf(f1,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1&&iid<2*COLL){iid=iid-COLL;};
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			double temp;
			if(flag==0){pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_1[iid][0]);}
			if(flag==1){pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_2[iid][0]);}
			if(flag==2){pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_3[iid][0]);}

			eui=Score-pScore;
			for(k=0;k<factorNum;k++){
			temp=user_buffer_1[uid][k];	
				if(flag==0){
					user_buffer_1[uid][k] += learnRate*(eui*item_buffer_1[iid][k] - regularzation*user_buffer_1[uid][k]);
					item_buffer_1[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_1[iid][k]);
				}
				if(flag==1){
					user_buffer_1[uid][k] += learnRate*(eui*item_buffer_2[iid][k] - regularzation*user_buffer_1[uid][k]);
					item_buffer_2[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_2[iid][k]);
				}
				if(flag==2){
					user_buffer_1[uid][k] += learnRate*(eui*item_buffer_3[iid][k] - regularzation*user_buffer_1[uid][k]);
					item_buffer_3[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_3[iid][k]);
				}
			}
		}
		
		fclose(f1);

		//send item_buffer_1 to process 3
		if(flag==0){
			//printf("flag 0 rank 0 is bcasting item_buffer_1\n");
			//MPI_Bcast(&item_buffer_1[0][0], COLL*factorNum, MPI_DOUBLE, 0, MPI_COMM_WORLD);
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,2,99,MPI_COMM_WORLD,&request[0]);
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,1,98,MPI_COMM_WORLD,&request[3]);

			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,1,88,MPI_COMM_WORLD,&request[1]);
			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,2,76,MPI_COMM_WORLD,&request[5]);

			MPI_Wait(&request[1],&status[1]);
			MPI_Wait(&request[5],&status[5]);
		}
		if(flag==1){
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,2,99,MPI_COMM_WORLD,&request[0]);
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,1,98,MPI_COMM_WORLD,&request[3]);

			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,1,88,MPI_COMM_WORLD,&request[1]);
			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,2,76,MPI_COMM_WORLD,&request[5]);
			
			MPI_Wait(&request[1],&status[1]);
			MPI_Wait(&request[5],&status[5]);
		}
		if(flag==2){
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,2,99,MPI_COMM_WORLD,&request[0]);
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,1,98,MPI_COMM_WORLD,&request[3]);

			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,1,88,MPI_COMM_WORLD,&request[1]);
			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,2,76,MPI_COMM_WORLD,&request[5]);

			MPI_Wait(&request[1],&status[1]);
			MPI_Wait(&request[5],&status[5]);
		}
				
	}

	if(rank==1){
		FILE*f2;
		if(flag==0){f2=fopen("./mydata/r11","r");}
		if(flag==1){f2=fopen("./mydata/r12","r");}
		if(flag==2){f2=fopen("./mydata/r10","r");}
		//training
		while(fscanf(f2,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1&&iid<2*COLL){iid=iid-COLL;};
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			if(uid>ROWL-1){uid=uid-ROWL;}
			double temp;
			if(flag==0){pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_2[iid][0]);}
			if(flag==1){pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_3[iid][0]);}
			if(flag==2){pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_1[iid][0]);}

			eui=Score-pScore;
			for(k=0;k<factorNum;k++){
			temp=user_buffer_2[uid][k];	
				if(flag==0){
					user_buffer_2[uid][k] += learnRate*(eui*item_buffer_2[iid][k] - regularzation*user_buffer_2[uid][k]);
					item_buffer_2[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_2[iid][k]);
				}
				if(flag==1){
					user_buffer_2[uid][k] += learnRate*(eui*item_buffer_3[iid][k] - regularzation*user_buffer_2[uid][k]);
					item_buffer_3[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_3[iid][k]);
				}
				if(flag==2){
					user_buffer_2[uid][k] += learnRate*(eui*item_buffer_1[iid][k] - regularzation*user_buffer_2[uid][k]);
					item_buffer_1[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_1[iid][k]);
				}
			}
		}
		
		fclose(f2);

		//send item_buffer_1 to process 3
		if(flag==0){
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,0,88,MPI_COMM_WORLD,&request[1]);
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,2,87,MPI_COMM_WORLD,&request[4]);

			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,2,77,MPI_COMM_WORLD,&request[2]);
			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,0,98,MPI_COMM_WORLD,&request[3]);

			MPI_Wait(&request[2],&status[2]);
			MPI_Wait(&request[3],&status[3]);
		}
		if(flag==1){
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,0,88,MPI_COMM_WORLD,&request[1]);
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,2,87,MPI_COMM_WORLD,&request[4]);

			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,2,77,MPI_COMM_WORLD,&request[2]);
			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,0,98,MPI_COMM_WORLD,&request[3]);

			MPI_Wait(&request[2],&status[2]);
			MPI_Wait(&request[3],&status[3]);
		}
		if(flag==2){
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,0,88,MPI_COMM_WORLD,&request[1]);
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,2,87,MPI_COMM_WORLD,&request[4]);

			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,2,77,MPI_COMM_WORLD,&request[2]);
			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,0,98,MPI_COMM_WORLD,&request[3]);

			MPI_Wait(&request[2],&status[2]);
			MPI_Wait(&request[3],&status[3]);
		}
				
	}

	if(rank==2){
		FILE*f3;
		if(flag==0){f3=fopen("./mydata/r22","r");}
		if(flag==1){f3=fopen("./mydata/r20","r");}
		if(flag==2){f3=fopen("./mydata/r21","r");}
		//training
		while(fscanf(f3,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1&&iid<2*COLL){iid=iid-COLL;};
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			if(uid>2*ROWL-1){uid=uid-2*ROWL;}
			double temp;
			if(flag==0){pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_3[iid][0]);}
			if(flag==1){pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_1[iid][0]);}
			if(flag==2){pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_2[iid][0]);}

			eui=Score-pScore;
			for(k=0;k<factorNum;k++){
			temp=user_buffer_3[uid][k];	
				if(flag==0){
					user_buffer_3[uid][k] += learnRate*(eui*item_buffer_3[iid][k] - regularzation*user_buffer_3[uid][k]);
					item_buffer_3[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_3[iid][k]);
				}
				if(flag==1){
					user_buffer_3[uid][k] += learnRate*(eui*item_buffer_1[iid][k] - regularzation*user_buffer_3[uid][k]);
					item_buffer_1[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_1[iid][k]);
				}
				if(flag==2){
					user_buffer_3[uid][k] += learnRate*(eui*item_buffer_2[iid][k] - regularzation*user_buffer_3[uid][k]);
					item_buffer_2[iid][k] += learnRate*(eui*temp - regularzation*item_buffer_2[iid][k]);
				}
			}
		}
		
		fclose(f3);

		//send item_buffer_1 to process 3
		if(flag==0){
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,1,77,MPI_COMM_WORLD,&request[2]);
			MPI_Isend(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,0,76,MPI_COMM_WORLD,&request[5]);

			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,0,99,MPI_COMM_WORLD,&request[0]);
			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,1,87,MPI_COMM_WORLD,&request[4]);

			MPI_Wait(&request[0],&status[0]);
			MPI_Wait(&request[4],&status[4]);
		}
		if(flag==1){
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,1,77,MPI_COMM_WORLD,&request[2]);
			MPI_Isend(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,0,76,MPI_COMM_WORLD,&request[5]);

			MPI_Irecv(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,0,99,MPI_COMM_WORLD,&request[0]);
			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,1,87,MPI_COMM_WORLD,&request[4]);

			MPI_Wait(&request[0],&status[0]);
			MPI_Wait(&request[4],&status[4]);
		}
		if(flag==2){
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,1,77,MPI_COMM_WORLD,&request[2]);
			MPI_Isend(&item_buffer_2[0][0],COLL*factorNum,MPI_DOUBLE,0,76,MPI_COMM_WORLD,&request[5]);

			MPI_Irecv(&item_buffer_3[0][0],tCOLL*factorNum,MPI_DOUBLE,0,99,MPI_COMM_WORLD,&request[0]);
			MPI_Irecv(&item_buffer_1[0][0],COLL*factorNum,MPI_DOUBLE,1,87,MPI_COMM_WORLD,&request[4]);

			MPI_Wait(&request[0],&status[0]);
			MPI_Wait(&request[4],&status[4]);
		}
				
	}

	MPI_Barrier(MPI_COMM_WORLD);
	//printf("Bcasting Finished\n");

	flag=(flag+1)%3;
	//calculate rmse
	rmse1=0;rmse2=0;rmse3=0;
	FILE*f11,*f22,*f33;
	if(rank==0){
		f11=fopen("./testdata/t00","r");
		f22=fopen("./testdata/t01","r");
		f33=fopen("./testdata/t02","r");
		
		while(fscanf(f11,"%d %d %d",&uid,&iid,&Score)!=EOF){
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_1[iid][0]);
			eui=Score-pScore;
			rmse1+=eui*eui;
		}
		while(fscanf(f22,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1){iid=iid-COLL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_2[iid][0]);
			eui=Score-pScore;
			rmse1+=eui*eui;
		}
		while(fscanf(f33,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_1[uid][0], &item_buffer_3[iid][0]);
			eui=Score-pScore;
			rmse1+=eui*eui;
		}
		fclose(f11);
		fclose(f22);
		fclose(f33);
		
		MPI_Isend(&rmse1,1,MPI_DOUBLE,1,99,MPI_COMM_WORLD,&request[0]);
		MPI_Isend(&rmse1,1,MPI_DOUBLE,2,98,MPI_COMM_WORLD,&request[3]);

		MPI_Irecv(&rmse2,1,MPI_DOUBLE,1,87,MPI_COMM_WORLD,&request[4]);
		MPI_Irecv(&rmse3,1,MPI_DOUBLE,2,77,MPI_COMM_WORLD,&request[2]);
		MPI_Wait(&request[4],&status[4]);
		MPI_Wait(&request[2],&status[2]);
	}

	if(rank==1){
		f11=fopen("./testdata/t10","r");
		f22=fopen("./testdata/t11","r");
		f33=fopen("./testdata/t12","r");
		
		while(fscanf(f11,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(uid>ROWL-1){uid=uid-ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_1[iid][0]);
			eui=Score-pScore;
			rmse2+=eui*eui;
		}
		while(fscanf(f22,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1){iid=iid-COLL;}
			if(uid>ROWL-1){uid=uid-ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_2[iid][0]);
			eui=Score-pScore;
			rmse2+=eui*eui;
		}
		while(fscanf(f33,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			if(uid>ROWL-1){uid=uid-ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_2[uid][0], &item_buffer_3[iid][0]);
			eui=Score-pScore;
			rmse2+=eui*eui;
		}
		fclose(f11);
		fclose(f22);
		fclose(f33);
		
		MPI_Isend(&rmse2,1,MPI_DOUBLE,2,88,MPI_COMM_WORLD,&request[1]);
		MPI_Isend(&rmse2,1,MPI_DOUBLE,0,87,MPI_COMM_WORLD,&request[4]);

		MPI_Irecv(&rmse1,1,MPI_DOUBLE,0,99,MPI_COMM_WORLD,&request[0]);
		MPI_Irecv(&rmse3,1,MPI_DOUBLE,2,76,MPI_COMM_WORLD,&request[5]);

		MPI_Wait(&request[0],&status[0]);
		MPI_Wait(&request[5],&status[5]);
	}

	if(rank==2){
		f11=fopen("./testdata/t20","r");
		f22=fopen("./testdata/t21","r");
		f33=fopen("./testdata/t22","r");
		
		while(fscanf(f11,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(uid>2*ROWL-1){uid=uid-2*ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_1[iid][0]);
			eui=Score-pScore;
			rmse3+=eui*eui;
		}
		while(fscanf(f22,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>COLL-1){iid=iid-COLL;}
			if(uid>2*ROWL-1){uid=uid-2*ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_2[iid][0]);
			eui=Score-pScore;
			rmse3+=eui*eui;
		}
		while(fscanf(f33,"%d %d %d",&uid,&iid,&Score)!=EOF){
			if(iid>2*COLL-1){iid=iid-2*COLL;}
			if(uid>2*ROWL-1){uid=uid-2*ROWL;}
			pScore = PredictScore(averageScore, 0, 0, &user_buffer_3[uid][0], &item_buffer_3[iid][0]);
			eui=Score-pScore;
			rmse3+=eui*eui;
		}
		fclose(f11);
		fclose(f22);
		fclose(f33);
		
		MPI_Isend(&rmse3,1,MPI_DOUBLE,0,77,MPI_COMM_WORLD,&request[2]);
		MPI_Isend(&rmse3,1,MPI_DOUBLE,1,76,MPI_COMM_WORLD,&request[5]);

		MPI_Irecv(&rmse1,1,MPI_DOUBLE,0,98,MPI_COMM_WORLD,&request[3]);
		MPI_Irecv(&rmse2,1,MPI_DOUBLE,1,88,MPI_COMM_WORLD,&request[1]);

		MPI_Wait(&request[3],&status[3]);
		MPI_Wait(&request[1],&status[1]);
		
	}

		MPI_Barrier(MPI_COMM_WORLD);
		//printf("Bcasting Rmse Finished\n");
		double rr=(rmse1+rmse2+rmse3)/dataNum;
		curRmse=sqrt(rr);
		if(rank==0){
			printf("curRmse=%lf,preRmse=%lf\n",curRmse,preRmse );
			fprintf(fo,"%lf\n",curRmse );
		}
		
		if (curRmse > preRmse||curRmse==preRmse||preRmse-curRmse<pow(10,-6)) { 
			//printf("it is time to break\n");
				break; 
		}
		else { 
			preRmse = curRmse; 
		}
}
	MPI_Finalize();
	fclose(fo);
	gettimeofday(&tv2,NULL);
	printf("average time:%.4fms\n",((double)(tv2.tv_sec-tv1.tv_sec)*1000+(double)(tv2.tv_usec-tv1.tv_usec)/1000));
	printf("Finished Exeuc\n");
	return 0;
}