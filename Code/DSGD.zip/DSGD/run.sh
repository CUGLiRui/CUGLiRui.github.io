#!/bin/bash
yhrun -n 3 -p bigdata ./DSGD