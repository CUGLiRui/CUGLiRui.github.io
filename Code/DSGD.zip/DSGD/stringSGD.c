#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<sys/time.h>
#include"mpi.h"


#define averageScore  3.528350
#define userNum  943
#define itemNum  1682 
#define factorNum 5
#define learnRate 0.009
#define regularzation 0.05
#define dataNum 20000

#define ROWL 314
#define COLL 560
#define tROWL 315
#define tCOLL 562

double Average(char* fileName) {
	FILE*fi;
	double result;
	int cnt,user,item,rating;
	long temp;
	result = 0.0;
	cnt = 0;
	if ((fi = fopen(fileName, "r")) == NULL) {
		printf("can not open the file\n");
		exit(0);
	}
	while (fscanf(fi, "%d %d %d %ld", &user, &item, &rating, &temp) != EOF) {
		cnt = cnt + 1;
		result += rating;
	}
	fclose(fi);
	return result / cnt;
}

double InerProduct(double*v1, double *v2) {
	double result;
	result = 0;
	int i,len;
	len = sizeof(v1) / sizeof(double);
	for (i = 0; i < len; i++) {
		result += v1[i] * v2[i];
	}

	return result;
}

double PredictScore(double av, double bu, double bi, double *pu, double *qi) {
	double pSore = av + bu + bi + InerProduct(pu, qi);
	if (pSore < 1) {
		pSore = 1;
	}
	else if (pSore > 5) {
		pSore = 5;
	}

	return pSore;
}

double Validate(char*testDataFile, double av, double*bu, double*bi, double pu[userNum][factorNum], double qi[itemNum][factorNum]) {
	int cnt;
	double rmse,tScore,pScore;
	long temp;
	int uid, iid;
	cnt = 0;
	rmse = 0.0;
	FILE*fi;
	if ((fi = fopen(testDataFile, "r")) == NULL) {
		printf("can not open\n");
	}
	while (fscanf(fi, "%d %d %lf %ld", &uid, &iid, &tScore, &temp) != EOF) {
		cnt++;
		pScore = PredictScore(av, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
		rmse += (tScore - pScore)*(tScore - pScore);
	}
	fclose(fi);
	return sqrt(rmse / cnt);
}

void SVD(char*configureFile, char*testFile,char*trainDataFile) {
	/*get the configure*/
	int cnt=0;
	int i, j, step, uid, iid, k;
	long ti;
	double rmse=0.0, tScore, pScore;
	double bi[itemNum], bu[userNum], qi[itemNum][factorNum], pu[userNum][factorNum];
	double preRmse = 1000000.0, curRmse, temp, eui;

	FILE*fii,*fi,*fo;

	//memset(bi, 0, itemNum * sizeof(double));
	//memset(bu, 0, userNum * sizeof(double));
	temp = sqrt(factorNum);
	srand((unsigned)time(NULL));
	double y;
	for (i = 0; i < itemNum; i++) {
		for (j = 0; j < factorNum; j++) {
			y = rand();
			//qi[i][j] = 0.1*(y/RAND_MAX+0.0) / temp;
			qi[i][j] = 1.0;
		}
	}

	for (i = 0; i < userNum; i++) {
		for (j = 0; j < factorNum; j++) {
			y = rand();
			//pu[i][j] = 0.1*(y/RAND_MAX + 0.0) / temp;
			pu[i][j] = 1.0;
		}
	}
	//printf("%lf %lf\n", qi[0][0], qi[0][1]);
	printf("initialization end\nstart training\n");

	/*train model*/

	if ((fo = fopen("rmse.txt", "w+")) == NULL) {
		printf("can not open\n");
	}
	i = 0;
	for (step = 0; step < 100000; step++) {
		fi = fopen(trainDataFile, "r");
		while (fscanf(fi, "%d %d %lf %ld", &uid, &iid, &tScore, &ti) != EOF) {
			i = i + 1;
			uid--;
			iid--;
			//pScore = PredictScore(averageScore, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
			pScore = PredictScore(averageScore, 0, 0, &pu[uid][0], &qi[iid][0]);
			eui = tScore - pScore;
			/*update parameters*/
			bu[uid] += learnRate*(eui - regularzation*bu[uid]);
			bi[iid] += learnRate*(eui - regularzation*bi[iid]);
			for (k = 0; k < factorNum; k++) {
				temp = pu[uid][k];
				pu[uid][k] += learnRate*(eui*qi[iid][k] - regularzation*pu[uid][k]);
				qi[iid][k] += learnRate*(eui*temp - regularzation*qi[iid][k]);
			}
		}
		fclose(fi);

		//Valilde the data
		if ((fii = fopen(testFile, "r")) == NULL) {
			printf("can not open\n");
		}
		while (fscanf(fii, "%d %d %lf %ld", &uid, &iid, &tScore, &ti) != EOF) {
			cnt++;
			uid--;
			iid--;
			//pScore = PredictScore(averageScore, bu[uid], bi[iid], &pu[uid][0], &qi[iid][0]);
			pScore = PredictScore(averageScore, 0, 0, &pu[uid][0], &qi[iid][0]);
			eui = tScore - pScore;
			rmse += eui*eui;
		}
		fclose(fii);
		curRmse = sqrt(rmse / cnt);

		printf("test_RMSE in step %d:%lf\n", step, curRmse);
		fprintf(fo, "%lf\n", curRmse);
		if (curRmse > preRmse||curRmse==preRmse||preRmse-curRmse<pow(10,-6)) { 
			printf("it is time to break\n");
				break; 
		}
		else { 
			preRmse = curRmse; 
		}
	}
	fclose(fo);
}

int main(){
	struct timeval tv1,tv2;
	gettimeofday(&tv1,NULL);
	SVD("svd.conf","u1.test","u1.base");
	gettimeofday(&tv2,NULL);
	printf("average time:%.4fms\n",((double)(tv2.tv_sec-tv1.tv_sec)*1000+(double)(tv2.tv_usec-tv1.tv_usec)/1000));
	return 0;
}
